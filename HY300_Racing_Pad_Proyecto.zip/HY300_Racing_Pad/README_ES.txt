HY300 RACING PAD — PROYECTO ANDROID
==================================

OBJETIVO
Aplicación Android nativa que intenta registrar el teléfono como mando Bluetooth HID para usarlo con un proyector HY300 y Beach Buggy Racing. No usa Internet dentro de la aplicación ni necesita instalar una app receptora en el proyector.

IMPORTANTE
- Esto es el PROYECTO FUENTE, no un APK ya compilado.
- La API BluetoothHidDevice existe desde Android 9, pero el fabricante del teléfono debe habilitar el perfil HID Device. Si el Tecno no lo permite, el proyecto no puede forzarlo.
- La compatibilidad con el HY300 y con Beach Buggy Racing solo se confirma probando el mando real.
- El APK debug no es una publicación de Play Store. Android puede mostrar advertencias al instalarlo.
- El APK generado por GitHub Actions es compilado automáticamente desde estos archivos; no necesita una PC propia, pero sí una cuenta de GitHub y subir el proyecto a un repositorio.

CONTROLES INCLUIDOS
- Girar izquierda/derecha (eje X)
- Acelerar, frenar
- A/B/X/Y y Start/Pausa

CÓMO GENERAR EL APK SOLO CON EL CELULAR (GitHub Actions)
1. Descarga y descomprime este ZIP en el teléfono usando el gestor de archivos.
2. Abre github.com en Chrome e inicia sesión o crea una cuenta.
3. Crea un repositorio nuevo llamado HY300-Racing-Pad. Déjalo privado si quieres mantener el código privado.
4. Sube el CONTENIDO de esta carpeta al repositorio, conservando las rutas. Deben quedar build.gradle, settings.gradle, gradle.properties, app/ y .github/workflows/build-apk.yml en la raíz del repositorio. No subas la carpeta HY300_Racing_Pad como una carpeta anidada extra.
5. En el repositorio abre la pestaña Actions. Si GitHub pide habilitar workflows, actívalos.
6. Haz un cambio mínimo o abre Actions y ejecuta “Build HY300 Racing Pad APK” con “Run workflow”. También se ejecuta automáticamente al subir cambios a main.
7. Abre la ejecución terminada en verde, baja a Artifacts y descarga HY300-Racing-Pad-debug-apk.
8. Extrae el APK del ZIP descargado, tócalo para instalarlo y permite a Chrome o Archivos instalar aplicaciones desconocidas solo si confías en el archivo que acabas de generar.

CÓMO EMPAREJAR
1. En el HY300, abre Configuración > Bluetooth o Mandos/Accesorios.
2. Abre HY300 Racing Pad en el Tecno y concede los permisos Bluetooth.
3. Deja la aplicación en primer plano. Acepta el aviso de visibilidad si Android lo muestra.
4. En el HY300, busca un dispositivo de entrada/control llamado HY300 Racing Pad y selecciónalo.
5. Cuando el estado diga CONECTADO, abre Beach Buggy Racing y prueba controles.
6. Si solo aparece en una lista de altavoces, esa no es la lista correcta: busca la sección de mandos/dispositivos de entrada.

PRIVACIDAD
El código de la app no solicita permiso de Internet ni contiene llamadas de red. GitHub Actions solo se usa para compilar el APK en la nube. Revisa el código antes de publicar o instalar cualquier APK.

SI FALLA
- “No se pudo registrar HID” o “no pudo abrir el perfil HID”: probable limitación de Bluetooth del teléfono/firmware.
- El proyector no ve el mando: revisa Bluetooth y la lista de dispositivos de entrada; no audio.
- Empareja pero el juego no responde: el juego/proyector podría no aceptar este descriptor HID o requerir otro mapa de botones.
- Para probar cambios de descriptor, elimina el mando emparejado en el HY300 y vuelve a emparejarlo.
