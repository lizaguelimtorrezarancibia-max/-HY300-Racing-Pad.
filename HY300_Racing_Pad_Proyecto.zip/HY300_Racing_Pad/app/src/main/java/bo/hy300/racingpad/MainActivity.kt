package bo.hy300.racingpad

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothHidDevice
import android.bluetooth.BluetoothHidDeviceAppSdpSettings
import android.bluetooth.BluetoothProfile
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executor

/** A focused Bluetooth HID gamepad UI for testing Beach Buggy Racing on an HY300 projector. */
class MainActivity : Activity() {
    private var adapter: BluetoothAdapter? = null
    private var hid: BluetoothHidDevice? = null
    private var connectedHost: BluetoothDevice? = null
    private lateinit var status: TextView
    private var registered = false
    private var buttons = 0
    private var axisX = 0
    private var axisY = 0

    private val hidDescriptor = byteArrayOf(
        0x05, 0x01,       // Usage Page (Generic Desktop)
        0x09, 0x05,       // Usage (Game Pad)
        0xA1.toByte(), 0x01, // Collection (Application)
        0x85.toByte(), 0x01, // Report ID 1
        0x05, 0x09,       // Usage Page (Button)
        0x19, 0x01, 0x29, 0x10, // Buttons 1..16
        0x15, 0x00, 0x25, 0x01, 0x75, 0x01, 0x95.toByte(), 0x10,
        0x81.toByte(), 0x02, // Input (Data, Variable, Absolute)
        0x05, 0x01, 0x09, 0x39, // Hat switch
        0x15, 0x00, 0x25, 0x07, 0x35, 0x00, 0x46, 0x3B, 0x01,
        0x65, 0x14, 0x75, 0x04, 0x95.toByte(), 0x01, 0x81.toByte(), 0x42,
        0x75, 0x04, 0x95.toByte(), 0x01, 0x81.toByte(), 0x03,
        0x05, 0x01, 0x09, 0x30, 0x09, 0x31, // X, Y
        0x15, 0x81.toByte(), 0x25, 0x7F, 0x75, 0x08, 0x95.toByte(), 0x02,
        0x81.toByte(), 0x02,
        0xC0.toByte()
    )

    private val hidCallback = object : BluetoothHidDevice.Callback() {
        override fun onAppStatusChanged(pluggedDevice: BluetoothDevice?, isRegistered: Boolean) {
            registered = isRegistered
            runOnUiThread {
                status.text = if (isRegistered) "MANDO LISTO · busca ‘HY300 Racing Pad’ en el proyector" else "Bluetooth HID no está registrado en este teléfono"
            }
            if (isRegistered) requestDiscoverable()
        }

        override fun onConnectionStateChanged(device: BluetoothDevice?, state: Int) {
            if (state == BluetoothProfile.STATE_CONNECTED) connectedHost = device
            if (state == BluetoothProfile.STATE_DISCONNECTED && connectedHost == device) connectedHost = null
            runOnUiThread {
                status.text = when (state) {
                    BluetoothProfile.STATE_CONNECTED -> "CONECTADO · abre Beach Buggy Racing"
                    BluetoothProfile.STATE_CONNECTING -> "Conectando con el proyector…"
                    BluetoothProfile.STATE_DISCONNECTED -> if (registered) "MANDO LISTO · busca ‘HY300 Racing Pad’ en el proyector" else "Desconectado"
                    else -> "Estado Bluetooth: $state"
                }
            }
            sendReport()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        adapter = BluetoothAdapter.getDefaultAdapter()
        buildInterface()
        if (adapter == null) {
            status.text = "Este teléfono no informa un adaptador Bluetooth compatible."
        } else if (hasBluetoothPermissions()) {
            startHid()
        } else {
            requestBluetoothPermissions()
        }
    }

    private fun buildInterface() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(18, 10, 18, 10)
            setBackgroundColor(Color.rgb(16, 24, 32))
        }
        val heading = TextView(this).apply {
            text = "HY300 RACING PAD"
            textSize = 22f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "Preparando Bluetooth…"; textSize = 13f; setTextColor(Color.rgb(53,199,244)); gravity = Gravity.CENTER
            setPadding(4, 8, 4, 10)
        }
        root.addView(heading, LinearLayout.LayoutParams(-1, -2))
        root.addView(status, LinearLayout.LayoutParams(-1, -2))
        val playArea = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; weightSum = 3f }
        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; weightSum = 3f }
        left.addView(TextView(this).apply { text = "DIRECCIÓN"; setTextColor(Color.LTGRAY); gravity = Gravity.CENTER; textSize = 12f }, LinearLayout.LayoutParams(-1, 36))
        val upDown = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        upDown.addView(makeButton("◀", "Girar izquierda", { axisX = -127; sendReport() }, { axisX = 0; sendReport() }), weighted())
        upDown.addView(makeButton("▶", "Girar derecha", { axisX = 127; sendReport() }, { axisX = 0; sendReport() }), weighted())
        left.addView(upDown, LinearLayout.LayoutParams(-1, 0, 1f))
        left.addView(makeButton("CENTRAR", "Centrar dirección", { axisX = 0; axisY = 0; sendReport() }, { }), LinearLayout.LayoutParams(-1, 58))
        playArea.addView(left, LinearLayout.LayoutParams(0, -1, 1.25f))

        val middle = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        middle.addView(TextView(this).apply { text = "ACELERAR"; setTextColor(Color.LTGRAY); gravity = Gravity.CENTER; textSize = 12f }, LinearLayout.LayoutParams(-1, 36))
        middle.addView(makeButton("▲\nGAS", "Acelerar", { setButton(0, true) }, { setButton(0, false) }), LinearLayout.LayoutParams(-1, 0, 1f))
        middle.addView(makeButton("▼\nFRENO", "Frenar", { setButton(1, true) }, { setButton(1, false) }), LinearLayout.LayoutParams(-1, 0, 1f))
        playArea.addView(middle, LinearLayout.LayoutParams(0, -1, 1f))

        val right = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        right.addView(TextView(this).apply { text = "BOTONES"; setTextColor(Color.LTGRAY); gravity = Gravity.CENTER; textSize = 12f }, LinearLayout.LayoutParams(-1, 36))
        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        row1.addView(makeButton("A", "Botón A", { setButton(2, true) }, { setButton(2, false) }), weighted())
        row1.addView(makeButton("B", "Botón B", { setButton(1, true) }, { setButton(1, false) }), weighted())
        right.addView(row1, LinearLayout.LayoutParams(-1, 0, 1f))
        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        row2.addView(makeButton("X", "Botón X", { setButton(3, true) }, { setButton(3, false) }), weighted())
        row2.addView(makeButton("Y", "Botón Y", { setButton(4, true) }, { setButton(4, false) }), weighted())
        right.addView(row2, LinearLayout.LayoutParams(-1, 0, 1f))
        right.addView(makeButton("START / PAUSA", "Start", { setButton(7, true) }, { setButton(7, false) }), LinearLayout.LayoutParams(-1, 58))
        playArea.addView(right, LinearLayout.LayoutParams(0, -1, 1.25f))
        root.addView(playArea, LinearLayout.LayoutParams(-1, 0, 1f))
        val note = TextView(this).apply { text = "Mantén pulsado para usar cada control. Empareja desde el Bluetooth del HY300, no desde el menú de audio."; textSize = 11f; setTextColor(Color.LTGRAY); gravity = Gravity.CENTER; setPadding(4, 8, 4, 0) }
        root.addView(note, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
    }

    private fun weighted() = LinearLayout.LayoutParams(0, -1, 1f).apply { setMargins(4, 4, 4, 4) }

    private fun makeButton(label: String, description: String, down: () -> Unit, up: () -> Unit): Button {
        return Button(this).apply {
            text = label; contentDescription = description; textSize = 17f; isAllCaps = false
            setTextColor(Color.WHITE); setBackgroundColor(Color.rgb(33, 57, 73)); setPadding(4, 4, 4, 4)
            setOnTouchListener { v, event ->
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> { v.isPressed = true; down(); true }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { v.isPressed = false; up(); true }
                    else -> true
                }
            }
        }
    }

    private fun setButton(index: Int, pressed: Boolean) {
        if (pressed) buttons = buttons or (1 shl index) else buttons = buttons and (1 shl index).inv()
        sendReport()
    }

    private fun makeReport(): ByteArray = byteArrayOf(
        (buttons and 0xFF).toByte(),
        ((buttons shr 8) and 0xFF).toByte(),
        0x08, // hat neutral
        axisX.toByte(), axisY.toByte()
    )

    private fun sendReport() {
        val host = connectedHost ?: return
        val device = hid ?: return
        try { device.sendReport(host, 1, makeReport()) } catch (_: SecurityException) { runOnUiThread { status.text = "Permiso Bluetooth denegado; vuelve a habilitarlo." } }
    }

    private fun hasBluetoothPermissions(): Boolean = Build.VERSION.SDK_INT < 31 ||
        (checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.BLUETOOTH_ADVERTISE) == PackageManager.PERMISSION_GRANTED)

    private fun requestBluetoothPermissions() {
        if (Build.VERSION.SDK_INT >= 31) requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_ADVERTISE), 41)
        else startHid()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 41 && hasBluetoothPermissions()) startHid() else status.text = "Necesito permiso de Bluetooth para funcionar."
    }

    private fun startHid() {
        val bt = adapter ?: return
        if (!bt.isEnabled) {
            status.text = "Activa Bluetooth y vuelve a abrir la aplicación."
            startActivity(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE))
            return
        }
        status.text = "Solicitando perfil Bluetooth HID…"
        val ok = bt.getProfileProxy(this, object : BluetoothProfile.ServiceListener {
            override fun onServiceConnected(profile: Int, proxy: BluetoothProfile?) {
                if (profile != BluetoothProfile.HID_DEVICE) return
                hid = proxy as? BluetoothHidDevice
                val settings = BluetoothHidDeviceAppSdpSettings("HY300 Racing Pad", "Bluetooth gamepad for Beach Buggy Racing", "HY300 Racing Pad", 0x00, hidDescriptor)
                val registeredCall = try { hid?.registerApp(settings, null, null, Executor { it.run() }, hidCallback) ?: false } catch (_: SecurityException) { false }
                if (!registeredCall) status.text = "No se pudo registrar HID. Este teléfono puede no admitir el modo mando."
                else status.text = "Registrando mando…"
            }
            override fun onServiceDisconnected(profile: Int) {
                hid = null; registered = false; connectedHost = null
                runOnUiThread { status.text = "Bluetooth HID se desconectó. Cierra y abre la aplicación." }
            }
        }, BluetoothProfile.HID_DEVICE)
        if (!ok) status.text = "Android no pudo abrir el perfil HID en este teléfono."
    }

    private fun requestDiscoverable() {
        try {
            if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_ADVERTISE) != PackageManager.PERMISSION_GRANTED) return
            startActivity(Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE).putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 300))
        } catch (_: Exception) { /* The projector may still discover the controller from its input-device scan. */ }
    }

    override fun onDestroy() {
        try { if (registered) hid?.unregisterApp() } catch (_: Exception) { }
        try { if (adapter != null && hid != null) adapter?.closeProfileProxy(BluetoothProfile.HID_DEVICE, hid) } catch (_: Exception) { }
        super.onDestroy()
    }
}
